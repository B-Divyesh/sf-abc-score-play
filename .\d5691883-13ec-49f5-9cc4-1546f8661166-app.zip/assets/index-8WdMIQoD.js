const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/index-BzKXPIl9.js","assets/abcjs-CUoT7yai.js"])))=>i.map(i=>d[i]);
(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))d(o);new MutationObserver(o=>{for(const a of o)if(a.type==="childList")for(const l of a.addedNodes)l.tagName==="LINK"&&l.rel==="modulepreload"&&d(l)}).observe(document,{childList:!0,subtree:!0});function s(o){const a={};return o.integrity&&(a.integrity=o.integrity),o.referrerPolicy&&(a.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?a.credentials="include":o.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function d(o){if(o.ep)return;o.ep=!0;const a=s(o);fetch(o.href,a)}})();const me="modulepreload",ye=function(t){return"/"+t},ae={},fe=function(e,s,d){let o=Promise.resolve();if(s&&s.length>0){let C=function(h){return Promise.all(h.map(f=>Promise.resolve(f).then(b=>({status:"fulfilled",value:b}),b=>({status:"rejected",reason:b}))))};var l=C;document.getElementsByTagName("link");const n=document.querySelector("meta[property=csp-nonce]"),u=n?.nonce||n?.getAttribute("nonce");o=C(s.map(h=>{if(h=ye(h),h in ae)return;ae[h]=!0;const f=h.endsWith(".css"),b=f?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${h}"]${b}`))return;const g=document.createElement("link");if(g.rel=f?"stylesheet":me,f||(g.as="script"),g.crossOrigin="",g.href=h,u&&g.setAttribute("nonce",u),document.head.appendChild(g),f)return new Promise((c,S)=>{g.addEventListener("load",c),g.addEventListener("error",()=>S(new Error(`Unable to preload CSS for ${h}`)))})}))}function a(n){const u=new Event("vite:preloadError",{cancelable:!0});if(u.payload=n,window.dispatchEvent(u),!u.defaultPrevented)throw n}return o.then(n=>{for(const u of n||[])u.status==="rejected"&&a(u.reason);return e().catch(a)})};let se;function be(){return se??=fe(()=>import("./index-BzKXPIl9.js").then(t=>t.i),__vite__mapDeps([0,1])).then(t=>t.default),se}function ve(t){if(!t.trim())return[];const e=t.split(`
`),s=[],d=["X:","T:","M:","L:","K:"];for(const a of d)e.some(l=>l.trimStart().startsWith(a))||s.push({line:1,message:`Add a ${a.slice(0,1)} header before the music.`});const o=e.findIndex(a=>a.trimStart().startsWith("K:"));return o>=0&&!e.slice(o+1).some(a=>/[A-Ga-gzZ]/.test(a.replace(/%.*/,"")))&&s.push({line:Math.min(o+2,e.length),message:"Add notes or rests after the K header."}),e.forEach((a,l)=>{const n=a.replace(/%.*/,"");(n.match(/"/g)?.length??0)%2!==0&&s.push({line:l+1,message:"Close the chord quote on this line."}),(n.match(/\[/g)?.length??0)!==(n.match(/\]/g)?.length??0)&&s.push({line:l+1,message:"Match the opening and closing square brackets."})}),s.slice(0,5)}function ge(t,e){return t.slice(0,Math.max(0,e)).split(`
`).length}function Se(t,e,s,d){const o=t.extractMeasures(e)[0];if(!o)return e;const a=Math.max(0,s-1),l=Math.min(o.measures.length,d),n=o.measures.slice(a,l).map(u=>u.abc).join("");return`${o.header}
${n}`}function we(t,e){return Math.max(1,t.extractMeasures(e)[0]?.measures.length??1)}function ne(t){const e=new TextEncoder().encode(t);let s="";return e.forEach(d=>{s+=String.fromCharCode(d)}),btoa(s).replaceAll("+","-").replaceAll("/","_").replaceAll("=","")}function Ce(t){try{const e=t.replaceAll("-","+").replaceAll("_","/")+"=".repeat((4-t.length%4)%4),s=atob(e),d=Uint8Array.from(s,o=>o.charCodeAt(0));return new TextDecoder().decode(d)}catch{return null}}class xe{context;sources=[];timers=[];stopped=!0;async play(e,s,d,o){this.stop(),this.stopped=!1,this.context??=new AudioContext,await this.context.resume();const a=e.setUpAudio({qpm:s,chordsOff:!0}),l=240/s,n=this.context.currentTime+.06,u=a.tracks.flatMap(c=>c).filter(c=>c.cmd==="note");for(const c of u){if(c.pitch===void 0||c.start===void 0||c.duration===void 0)continue;const S=this.context.createOscillator(),m=this.context.createGain(),y=n+c.start*l,k=Math.max(.04,c.duration*l-.025),M=Math.min(.13,Math.max(.035,(c.volume??80)/900));S.type="triangle",S.frequency.value=440*2**((c.pitch-69)/12),m.gain.setValueAtTime(1e-4,y),m.gain.exponentialRampToValueAtTime(M,y+.012),m.gain.setValueAtTime(M,Math.max(y+.013,y+k-.045)),m.gain.exponentialRampToValueAtTime(1e-4,y+k),S.connect(m).connect(this.context.destination),S.start(y),S.stop(y+k+.01),this.sources.push(S)}const C=e.getMeterFraction(),h=C.den?C.num/C.den:1,f=Math.max(.1,h*l),b=Math.max(.08,a.totalDuration*l),g=Math.max(1,Math.ceil(b/f));for(let c=0;c<g;c+=1)this.timers.push(window.setTimeout(()=>{this.stopped||d(c)},60+c*f*1e3));this.timers.push(window.setTimeout(()=>{this.stopped||o()},(b+.08)*1e3))}stop(){this.stopped=!0,this.timers.forEach(window.clearTimeout),this.timers=[];for(const e of this.sources)try{e.stop()}catch{}this.sources=[]}}const D=`X:1
T:Evening Scale Study
C:ABC Score Play sample
M:4/4
L:1/8
Q:1/4=104
K:G
|: G2 B2 d2 B2 | A2 c2 e2 c2 |
G2 A2 B2 c2 | d4 B4 :|
|: e2 d2 c2 B2 | A2 G2 F2 D2 |
G2 B2 A2 F2 | G8 :|`,Le="abc-score-play:score",O="demo:abc-score-play:score",Ae="v1.0.0",N=document.querySelector("#app");let j;function G(){return`<a class="skip-link" href="#main">Skip to score editor</a>
    <header class="site-header">
      <a class="wordmark" href="/" data-route><span class="wordmark-mark" aria-hidden="true">ABC</span><span>Score Play</span></a>
      <nav class="site-nav" aria-label="Main navigation">
        <a href="/demo" data-route>Demo</a>
        <a href="/#workbench">Editor</a>
        <a href="/privacy" data-route>Privacy</a>
      </nav>
    </header>`}function U(){return`<footer class="site-footer">
      <p>Write a short ABC score, hear it, and practice a loop.</p>
      <nav class="footer-links" aria-label="Footer navigation"><a href="/privacy" data-route>Privacy</a><a href="/terms" data-route>Terms</a></nav>
      <p>Built by Param Factory · ${Ae} · <span>Original generated artwork</span></p>
    </footer>
    <div class="visually-hidden" id="route-status" aria-live="polite"></div>`}function R(t,e,s){document.title=t,document.querySelector('meta[name="description"]').content=e,document.querySelector('link[rel="canonical"]').href=`https://abc-score-play.sociobot.in${s}`}function le(t){return`<section class="work-section" id="workbench" aria-labelledby="workbench-title">
      <div class="section-heading">
        <p class="eyebrow">Practice console · local session</p>
        <h2 id="workbench-title">Turn text into a practice loop</h2>
        <p>Write ABC on the left. The staff updates on the right.</p>
      </div>
      <div class="workbench">
        <section class="editor-panel" aria-labelledby="editor-title">
          <div class="panel-head">
            <div class="panel-title"><span class="status-lamp" id="valid-lamp" aria-hidden="true"></span><h3 id="editor-title">ABC source</h3></div>
            <span id="validation-label">Waiting for notes</span>
          </div>
          <label class="visually-hidden" for="abc-source">ABC score text</label>
          <div class="editor-wrap">
            <div class="line-gutter" id="line-gutter" aria-hidden="true">1</div>
            <textarea id="abc-source" spellcheck="false" autocapitalize="off" aria-describedby="editor-help validation-errors" placeholder="Start with X:, T:, M:, L:, and K: headers."></textarea>
          </div>
          <p id="editor-help" class="score-help">Tip: write a bar with notes such as <code>| C2 D2 E2 F2 |</code>.</p>
          <div id="validation-errors" aria-live="polite"></div>
          <div class="editor-actions">
            <button class="button small" id="load-sample" type="button">Load sample score</button>
            <button class="button small" id="share-score" type="button" disabled>Copy score link</button>
            <button class="button small" id="print-score" type="button" disabled>Print score card</button>
            <button class="button small" id="clear-score" type="button">Clear editor</button>
          </div>
        </section>
        <section class="score-panel" aria-labelledby="score-title">
          <div class="panel-head"><div class="panel-title"><h3 id="score-title">Rendered score</h3></div><span id="bar-count">0 bars</span></div>
          <div class="paper-bay" id="paper-bay" tabindex="0" role="region" aria-label="Scrollable score paper">
            <div class="empty-score" id="empty-score"><strong>Your staff will appear here.</strong><p>Write ABC or load the sample score.</p></div>
            <div id="paper" role="img" aria-label="Rendered music notation"></div>
          </div>
          <div class="transport" id="transport">
            <div class="transport-keys">
              <button class="button primary" id="play-score" type="button" disabled><span class="play-lamp" aria-hidden="true"></span><span>Play score</span></button>
              <button class="button" id="stop-score" type="button" disabled>Stop</button>
            </div>
            <div class="field">
              <label for="tempo">Practice tempo</label>
              <div class="tempo-row"><input id="tempo" type="range" min="40" max="220" value="104" step="1"><input id="tempo-number" type="number" min="40" max="220" value="104" aria-label="Tempo in beats per minute"></div>
            </div>
            <div class="loop-panel">
              <div class="field"><label for="loop-start">Loop from bar</label><input id="loop-start" type="number" min="1" value="1"></div>
              <div class="field"><label for="loop-end">Loop to bar</label><input id="loop-end" type="number" min="1" value="1"></div>
              <button class="button coral" id="play-loop" type="button" disabled>Play loop</button>
              <p class="loop-summary" id="loop-summary">Choose a valid score to set a loop.</p>
            </div>
          </div>
          <p class="score-help">Select a bar in the staff to loop it. Press Space to play or stop.</p>
          <p class="app-status" id="app-status" role="status" aria-live="polite">${t?"Sample score ready.":"Write or load a score to begin."}</p>
        </section>
      </div>
    </section>`}function Ee(){return`${G()}<main id="main" tabindex="-1">
    <section class="hero">
      <div>
        <p class="eyebrow">ABC notation practice tool</p>
        <h1>Write, hear, and loop an ABC score</h1>
        <p class="lede">For musicians and teachers who need a short score ready to practise or share.</p>
        <div class="hero-action-row">
          <a class="button primary" href="/demo" data-route>Try it with sample data</a>
          <p class="action-note">It loads a complete score, ready to play.</p>
        </div>
        <ul class="facts"><li>Free to use</li><li>Your score stays in this browser</li><li>Works offline after the first visit</li></ul>
      </div>
      <figure class="hero-art-shell">
        <picture>
          <source srcset="/assets/abc-score-play-hero.avif" type="image/avif">
          <img class="hero-art" src="/assets/abc-score-play-hero.webp" width="900" height="600" alt="A music console turns typed notes into a paper score." fetchpriority="high" decoding="async">
        </picture>
      </figure>
    </section>
    ${le(!1)}
    <section class="how" aria-labelledby="how-title">
      <p class="eyebrow">Three moves</p><h2 id="how-title">How to make a practice loop</h2>
      <div class="how-grid">
        <article class="step"><span class="step-number">01</span><h3>Write the tune</h3><p>Type standard ABC headers and notes. Errors point to a line.</p></article>
        <article class="step"><span class="step-number">02</span><h3>Choose the bars</h3><p>Set the first and last bar. Change the tempo for practice.</p></article>
        <article class="step"><span class="step-number">03</span><h3>Play or share</h3><p>Repeat the loop, copy its link, or print the clean score.</p></article>
      </div>
    </section>
    <section class="boundaries" aria-labelledby="boundaries-title">
      <div><p class="eyebrow">Kept focused</p><h2 id="boundaries-title">A practice tool, not a score library</h2></div>
      <div><ul class="boundary-list"><li>No account or cloud score storage.</li><li>No copyrighted score catalogue.</li><li>No composing bot or group editing.</li><li>Your browser stores the current ABC text.</li></ul></div>
    </section>
  </main>${U()}`}function Te(){return`${G()}<div class="demo-strip" role="status"><span>Demo — sample data, nothing is saved to your real score</span><button id="reset-demo" type="button">Reset demo</button><button id="start-real" type="button">Start for real</button></div>
    <main id="main" tabindex="-1">
      <section class="hero demo-hero">
        <div><p class="eyebrow">Sample practice session</p><h1>Play a ready-made ABC score</h1><p class="lede">Edit the scale study, choose bars, and hear the loop repeat.</p></div>
        <div class="hero-art-shell" aria-hidden="true"><img class="hero-art" src="/assets/abc-score-play-hero.webp" width="900" height="600" alt=""></div>
      </section>
      ${le(!0)}
    </main>${U()}`}function ie(t){const e=t==="privacy",s=e?"Keep your score on this device":"Use the tool for scores you may share";return`${G()}<main id="main" tabindex="-1"><article class="legal-page">
    <p class="eyebrow">${e?"Privacy":"Terms"}</p><h1>${s}</h1>
    ${e?'<h2>What this tool stores</h2><p>The app stores your current ABC text in this browser. Demo text uses a separate demo key.</p><h2>What leaves this device</h2><p>Your score is not sent to us. A shared link holds the score in its URL fragment, which browsers do not send to servers.</p><h2>Control your score</h2><p>Use “Clear editor” to remove saved text. Clearing browser storage also removes it.</p><h2>Contact</h2><p>Email <a href="mailto:privacy@sociobot.in">privacy@sociobot.in</a> with a privacy question.</p>':'<h2>Your scores</h2><p>Only enter music you wrote or have permission to use. You remain responsible for links and printed copies you share.</p><h2>The service</h2><p>ABC Score Play is provided free of charge and without a warranty. The tool may change or stop.</p><h2>Acceptable use</h2><p>Do not use the service to break laws, distribute harmful material, or infringe another person’s rights.</p><h2>Contact</h2><p>Email <a href="mailto:hello@sociobot.in">hello@sociobot.in</a> with a terms question.</p>'}
    <p><a href="/" data-route>Return to the score editor</a></p>
  </article></main>${U()}`}function ke(){return`${G()}<main id="main" tabindex="-1"><section class="not-found"><p class="not-found-code">404</p><h1>This bar is not in the score</h1><p>The page address does not match a part of ABC Score Play.</p><a class="button primary" href="/" data-route>Return to the editor</a></section></main>${U()}`}function $e(){const t=location.hash.match(/(?:^#|&)score=([^&]+)/);return t?Ce(t[1]):null}function F(t,e){const s=document.querySelector("#line-gutter");if(!s)return;const d=new Set(e.map(o=>o.line));s.innerHTML=t.split(`
`).map((o,a)=>`<span${d.has(a+1)?' class="line-error"':""}>${a+1}</span>`).join(`
`)}function ce(t){const e=document.querySelector("#abc-source"),s=document.querySelector("#paper"),d=document.querySelector("#empty-score"),o=document.querySelector("#validation-errors"),a=document.querySelector("#valid-lamp"),l=document.querySelector("#validation-label"),n=document.querySelector("#app-status"),u=document.querySelector("#play-score"),C=document.querySelector("#stop-score"),h=document.querySelector("#play-loop"),f=document.querySelector("#share-score"),b=document.querySelector("#print-score"),g=document.querySelector("#transport"),c=document.querySelector("#tempo"),S=document.querySelector("#tempo-number"),m=document.querySelector("#loop-start"),y=document.querySelector("#loop-end"),k=document.querySelector("#loop-summary"),M=document.querySelector("#bar-count"),P=new xe,W=t?O:Le;let $,x,w=0,V=0,ee=0,H=!1,A=0;const I=r=>{g.classList.toggle("is-playing",r),u.querySelector("span:last-child").textContent=r&&!H?"Playing score":"Play score",C.disabled=!r},Y=()=>s.querySelectorAll(".playing").forEach(r=>r.classList.remove("playing")),ue=r=>{Y(),s.querySelectorAll(`.abcjs-mm${r}`).forEach(i=>i.classList.add("playing"))},q=async()=>{const r=++ee,i=e.value,v=ve(i);if(F(i||"",v),P.stop(),I(!1),!i.trim()){x=void 0,w=0,s.innerHTML="",d.hidden=!1,l.textContent="Waiting for notes",a.className="status-lamp",o.innerHTML="",[u,h,f,b].forEach(p=>{p.disabled=!0}),M.textContent="0 bars",k.textContent="Choose a valid score to set a loop.";return}if(v.length){x=void 0,a.className="status-lamp error",l.textContent=`${v.length} ${v.length===1?"issue":"issues"}`,o.innerHTML=`<div class="error-list"><strong>Fix the ABC text:</strong><ul>${v.map(p=>`<li><button type="button" data-error-line="${p.line}">Line ${p.line}</button>: ${p.message}</li>`).join("")}</ul></div>`,F(i,v),[u,h,f,b].forEach(p=>{p.disabled=!0});return}l.textContent="Reading score…";try{if($??=await be(),r!==ee)return;const L=$.renderAbc(s,i,{responsive:"resize",add_classes:!0,selectionColor:"#c54f38",paddingtop:12,paddingbottom:12,clickListener:(E,T,X,Q)=>{const he=`${X} ${Q.parentClasses.join(" ")} ${Q.clickedClasses.join(" ")}`.match(/abcjs-mm(\d+)/)?.[1],Z=Math.min(w,Math.max(1,Number(he??Q.measure)+1));m.value=String(Z),y.value=String(Z),K(),n.textContent=`Bar ${Z} selected for looping.`}})[0];if(!L)throw new Error("No tune was found.");const B=(L.warnings??[]).filter(Boolean);if(B.length){const E=B.slice(0,4).map(T=>{const X=Number(T.match(/(?:character|char)\s+(\d+)/i)?.[1]??0);return{line:ge(i,X),message:String(T).replace(/<[^>]*>/g,"").slice(0,180)}});o.innerHTML=`<div class="error-list"><strong>Check this notation:</strong><ul>${E.map(T=>`<li><button type="button" data-error-line="${T.line}">Line ${T.line}</button>: ${T.message}</li>`).join("")}</ul></div>`,F(i,E)}else o.innerHTML="";x=L,w=we($,i),d.hidden=!0,a.className="status-lamp valid",l.textContent=B.length?"Score drawn with warnings":"Valid score",M.textContent=`${w} ${w===1?"bar":"bars"}`,m.max=String(w),y.max=String(w),m.value=String(Math.min(Number(m.value),w)),y.value=String(Math.min(Math.max(Number(y.value),Number(m.value)),w)),[u,h,f,b].forEach(E=>{E.disabled=!1}),K()}catch(p){x=void 0,a.className="status-lamp error",l.textContent="Could not draw score",o.innerHTML='<div class="error-list"><strong>The score could not be drawn.</strong> Check the headers and bar lines, then try again.</div>',n.textContent=p instanceof Error?p.message:"The score could not be drawn.",[u,h,f,b].forEach(L=>{L.disabled=!0})}},K=()=>{const r=Math.max(1,Math.min(w||1,Number(m.value)||1)),i=Math.max(r,Math.min(w||1,Number(y.value)||r));m.value=String(r),y.value=String(i),k.textContent=r===i?`Bar ${r} will repeat until you stop.`:`Bars ${r}–${i} will repeat until you stop.`},_=async(r,i)=>{H=i,I(!0),n.textContent=i?A?`Loop played ${A} ${A===1?"time":"times"} and is repeating.`:"Loop playing. Press Stop when finished.":"Score playing.";const v=i?Number(m.value)-1:0;await P.play(r,Number(c.value),p=>ue(p+v),async()=>{H?(A+=1,n.textContent=`Loop played ${A} ${A===1?"time":"times"}.`,await _(r,!0)):(I(!1),Y(),n.textContent="Score finished.")})},z=()=>{H=!1,P.stop(),I(!1),Y(),n.textContent="Playback stopped."},te=$e()??localStorage.getItem(W)??(t?D:"");e.value=te,F(te,[]),q();const pe=()=>{localStorage.setItem(W,e.value),window.clearTimeout(V),V=window.setTimeout(()=>{q()},220)};e.addEventListener("input",pe),e.addEventListener("scroll",()=>{document.querySelector("#line-gutter").scrollTop=e.scrollTop}),s.addEventListener("pointerdown",r=>{const v=[...r.target.closest('[class*="abcjs-mm"]')?.classList??[]].find(L=>/^abcjs-mm\d+$/.test(L))?.slice(8);if(v===void 0)return;const p=Math.min(w,Number(v)+1);m.value=String(p),y.value=String(p),K(),n.textContent=`Bar ${p} selected for looping.`},{capture:!0}),o.addEventListener("click",r=>{const i=r.target.closest("[data-error-line]");if(!i)return;const v=Number(i.dataset.errorLine),p=e.value.split(`
`).slice(0,v-1).reduce((B,E)=>B+E.length+1,0),L=p+(e.value.split(`
`)[v-1]?.length??0);e.focus(),e.setSelectionRange(p,L)}),document.querySelector("#load-sample").addEventListener("click",()=>{e.value=D,localStorage.setItem(W,e.value),n.textContent="Sample score loaded.",q()}),document.querySelector("#clear-score").addEventListener("click",()=>{z(),e.value="",localStorage.removeItem(W),n.textContent="Editor cleared.",q(),e.focus()}),u.addEventListener("click",()=>{x&&(A=0,_(x,!1))}),h.addEventListener("click",async()=>{if(!$||!x)return;P.stop(),A=0;const r=Se($,e.value,Number(m.value),Number(y.value)),i=$.renderAbc("*",r,{})[0];i&&await _(i,!0)}),C.addEventListener("click",z),[m,y].forEach(r=>r.addEventListener("change",K));const oe=r=>{const i=Math.max(40,Math.min(220,Number(r)||104));c.value=String(i),S.value=String(i),n.textContent=`Tempo set to ${i} beats per minute.`};c.addEventListener("input",()=>oe(c.value)),S.addEventListener("change",()=>oe(S.value)),f.addEventListener("click",async()=>{const r=`${location.origin}${t?"/demo":"/"}#score=${ne(e.value)}`;history.replaceState({},"",`${location.pathname}#score=${ne(e.value)}`);try{await navigator.clipboard.writeText(r),n.textContent="Score link copied."}catch{n.textContent="The score link is in the address bar. Copy it there."}}),b.addEventListener("click",()=>{n.textContent="Print view opened.",window.print()});const re=r=>{r.code!=="Space"||r.altKey||r.ctrlKey||r.metaKey||r.shiftKey||r.target instanceof HTMLTextAreaElement||r.target instanceof HTMLInputElement||(r.preventDefault(),g.classList.contains("is-playing")?z():x&&_(x,!1))};return document.addEventListener("keydown",re),document.querySelector("#reset-demo")?.addEventListener("click",()=>{localStorage.removeItem(O),e.value=D,localStorage.setItem(O,D),n.textContent="Demo reset.",q()}),document.querySelector("#start-real")?.addEventListener("click",()=>{localStorage.removeItem(O),de("/#workbench")}),()=>{P.stop(),window.clearTimeout(V),document.removeEventListener("keydown",re)}}function Me(){document.querySelectorAll("a[data-route]").forEach(t=>t.addEventListener("click",e=>{e.metaKey||e.ctrlKey||e.shiftKey||e.altKey||(e.preventDefault(),de(t.getAttribute("href")??"/"))}))}function de(t){history.pushState({},"",t),J(!0)}function J(t=!1){j?.(),j=void 0;const e=location.pathname.replace(/\/+$/,"")||"/";if(e==="/"?(R("ABC Score Play — write, hear, and loop music","Write a short ABC score, hear it, loop bars for practice, share a link, and print clean notation.","/"),N.innerHTML=Ee(),j=ce(!1)):e==="/demo"?(R("Demo — ABC Score Play","Try a sample ABC score, play it, and repeat selected bars.","/demo"),N.innerHTML=Te(),j=ce(!0)):e==="/privacy"?(R("Privacy — ABC Score Play","How ABC Score Play keeps score text in your browser.","/privacy"),N.innerHTML=ie("privacy")):e==="/terms"?(R("Terms — ABC Score Play","Terms for using ABC Score Play.","/terms"),N.innerHTML=ie("terms")):(R("Page not found — ABC Score Play","Return to the ABC Score Play editor.",e),N.innerHTML=ke()),Me(),t){window.scrollTo(0,0),document.querySelector("#main")?.focus();const d=document.querySelector("#route-status");d&&(d.textContent=document.querySelector("h1")?.textContent??document.title)}else location.hash==="#workbench"&&requestAnimationFrame(()=>document.querySelector("#workbench")?.scrollIntoView())}window.addEventListener("popstate",()=>J(!0));J();"serviceWorker"in navigator&&window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}));
